from .DataProcessor import DataProcessor 
from .DataProcessorRegister import DataProcessorRegister
register = DataProcessorRegister()


