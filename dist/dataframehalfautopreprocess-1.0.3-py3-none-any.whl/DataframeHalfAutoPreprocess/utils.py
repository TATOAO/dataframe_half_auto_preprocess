from .DataProcessor import DataProcessor 
from .DataProcessorRegister import DataProcessorRegister

__all__ = ["register"]

register = DataProcessorRegister()
